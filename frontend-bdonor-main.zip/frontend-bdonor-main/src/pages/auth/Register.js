import React from "react";
import Form from "../../components/shared/Form/Form";
import { useSelector } from "react-redux";
import Spinner from "../../components/shared/Spinner";
import { toast } from "react-toastify";

const Register = () => {
  const { loading, error } = useSelector((state) => state.auth);
  // Show error toast if there's an error
  React.useEffect(() => {
    if (error) {
      toast.error(error);
    }
  }, [error]);

  return (
    <>
      {loading ? (
        <Spinner />
      ) : (
        <div className="flex flex-col lg:flex-row min-h-screen bg-gray-50">
          {/* Banner image - now visible on all screens but as a smaller top banner on mobile */}
          <div className="relative overflow-hidden h-40 sm:h-60 lg:h-auto lg:w-3/5 xl:w-2/3">
            <img 
              src="./assets/images/banner2.jpg" 
              alt="Register Banner" 
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-blue-900/80 to-blue-900/40 flex items-center">
              <div className="text-white p-4 sm:p-8 lg:p-12 max-w-xl">
                <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold mb-2 sm:mb-4">Join Our Blood Bank Network</h1>
                <p className="text-sm sm:text-lg lg:text-xl">Register to become a donor, hospital, or organization and help save lives.</p>
              </div>
            </div>
          </div>
          {/* Form container - now takes full width on mobile and proper proportion on larger screens */}
          <div className="w-full lg:w-2/5 xl:w-1/3 p-4 sm:p-6 lg:p-8 flex items-center justify-center bg-white lg:bg-gray-50 shadow-md lg:shadow-none">
            <div className="w-full max-w-md">
              <Form
                formTitle={"Register"}
                submitBtn={"Register"}
                formType={"register"}
              />
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Register;
