import React from "react";

const InputType = ({
  labelText,
  labelFor,
  inputType,
  value,
  onChange,
  name,
}) => {
  return (
    <>
      <div className="mb-4">
        <label htmlFor={labelFor} className="block text-sm font-medium text-gray-700 mb-1">
          {labelText}
        </label>
        <input
          type={inputType}
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors duration-200"
          name={name}
          value={value}
          onChange={onChange}
          required
        />
      </div>
    </>
  );
};

export default InputType;
